package weilin.com.utils;

import org.junit.jupiter.api.Test;

public class MD5Util_Test {
    @Test
    public void testMD5() {
        String password = "123456789";
        String newPassword=new Md5Util().encode(password);
        System.out.println(newPassword);
    }
}
