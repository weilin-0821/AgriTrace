package weilin.com.controller;

import weilin.com.pojo.Result;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import weilin.com.utils.AliyunOssUtil;

import java.util.UUID;

@RestController
@RequestMapping("file")
public class FileUploadController {
    @PostMapping("/upload")
    public Result<String> upload(MultipartFile file) throws Exception {
        String originalFilename = file.getOriginalFilename();
        String fileName = UUID.randomUUID().toString()+originalFilename.substring(originalFilename.lastIndexOf("."));
//        file.transferTo(new File("D:\\WorkSpace\\big_event_file\\"+fileName));
        AliyunOssUtil.uploadFile(fileName,file.getInputStream());
        return Result.success("https://agri-trace-weilin.oss-cn-beijing.aliyuncs.com/"+fileName);

    }
}
