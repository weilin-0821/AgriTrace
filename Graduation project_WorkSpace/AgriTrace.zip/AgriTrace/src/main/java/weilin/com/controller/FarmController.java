package weilin.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import weilin.com.pojo.Farm;
import weilin.com.pojo.Result;
import weilin.com.service.FarmService;
import weilin.com.utils.ThreadLocalUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/farm")
public class FarmController {
    @Autowired
    private FarmService farmService;

    @GetMapping("list")
    public Result list() {
        Map<String, Object>map =ThreadLocalUtil.get();
        List<Farm> list= farmService.getAllFarmByUserId((Integer) map.get("userId"));
        return Result.success(list);
    }
    @PostMapping("/add")
    public Result addFarm(@RequestBody Farm farm) {
        Map<String, Object> map =ThreadLocalUtil.get();
        farm.setUserId((Integer) map.get("userId"));
        farmService.addFarm(farm);
        return Result.success();
    }
    @PostMapping("/update")
    public Result updataFarm(@RequestBody Farm farm) {
        farmService.updateFarm(farm);
        return Result.success();
    }
    @DeleteMapping("/delete")
    public Result deleteFarm(Integer farmId) {
        System.out.println(farmId);
        farmService.deleteFarm(farmId);
        return Result.success();
    }

}
