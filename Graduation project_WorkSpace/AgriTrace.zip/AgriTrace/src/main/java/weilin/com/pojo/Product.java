package weilin.com.pojo;

import java.time.LocalDateTime;

public class Product {
    private Integer productId;     // 农产品唯一ID
    private String name;           // 农产品名称
    private String description;    // 产品描述
    private Integer farmId;      // 产地
    private Integer shelfLife;     // 保质期（天数）
    private Integer categoryId;    // 农产品种类ID（外键，关联ProductCategory表）
    private LocalDateTime createTime;       // 创建时间
    private LocalDateTime updateTime;       // 修改时间
    private String farmName;
    private String categoryName;

    @Override
    public String toString() {
        return "Product{" +
                "productId=" + productId +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", farmId=" + farmId +
                ", shelfLife=" + shelfLife +
                ", categoryId=" + categoryId +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", farmName='" + farmName + '\'' +
                ", categoryName='" + categoryName + '\'' +
                '}';
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getFarmId() {
        return farmId;
    }

    public void setFarmId(Integer farmId) {
        this.farmId = farmId;
    }

    public Integer getShelfLife() {
        return shelfLife;
    }

    public void setShelfLife(Integer shelfLife) {
        this.shelfLife = shelfLife;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public String getFarmName() {
        return farmName;
    }

    public void setFarmName(String farmName) {
        this.farmName = farmName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Product() {
    }

    public Product(Integer productId, String name, String description, Integer farmId, Integer shelfLife, Integer categoryId, LocalDateTime createTime, LocalDateTime updateTime, String farmName, String categoryName) {
        this.productId = productId;
        this.name = name;
        this.description = description;
        this.farmId = farmId;
        this.shelfLife = shelfLife;
        this.categoryId = categoryId;
        this.createTime = createTime;
        this.updateTime = updateTime;
        this.farmName = farmName;
        this.categoryName = categoryName;
    }
}
