package weilin.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import weilin.com.pojo.PageBean;
import weilin.com.pojo.Product;
import weilin.com.pojo.Result;
import weilin.com.service.ProductService;

import java.util.List;

@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping("/list")
    public Result<PageBean<Product>> list(Integer pageNum,
                                          Integer pageSize,
                                          @RequestParam(required = false) Integer categoryId,
                                          @RequestParam(required = false) Integer farmId) {
        PageBean<Product> pageBean = productService.list(pageNum, pageSize, categoryId, farmId);

        return Result.success(pageBean);
    }

    @PostMapping("/add")
    public Result<Product> add(@RequestBody Product product) {
        productService.add(product);
        return Result.success(product);
    }

    @PostMapping("/update")
    public Result updata(@RequestBody Product product) {
        productService.update(product);
        return Result.success();
    }

    @DeleteMapping("/delete")
    public Result delete(Integer productId) {
        productService.delete(productId);
        return Result.success();
    }

    @PostMapping("/find")
    public Result<Product> find(@RequestParam Integer productId) {
       Product product= productService.getProduct(productId);
        return Result.success(product);
    }
}
