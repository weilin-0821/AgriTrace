package weilin.com.service;

import weilin.com.pojo.PageBean;
import weilin.com.pojo.Product;

import java.util.List;

public interface ProductService {
    public PageBean<Product> list(Integer pageNum,
                                  Integer pageSize,
                                  Integer categoryId,
                                  Integer farmId);
    public void add(Product product);

    public void update(Product product);

    public void delete(Integer ProductId);

    public Product getProduct(Integer productId);
}
