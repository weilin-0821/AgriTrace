package weilin.com.pojo;

import java.time.LocalDateTime;

public class QualityCheck {
    private Integer checkId;       // 检测记录唯一ID
    private Integer productId;     // 农产品ID（外键，关联Product表）
    private LocalDateTime checkDate;        // 检测日期
    private String result;         // 检测结果（合格/不合格/待检）
    private String checkDetails;   // 检测详细信息
    private Integer checkedBy;     // 检测负责人ID（外键，关联User表）
    private LocalDateTime createTime;       // 创建时间
    private LocalDateTime updateTime;       // 修改时间

    public QualityCheck() {
    }

    public QualityCheck(Integer checkId, Integer productId, LocalDateTime checkDate, String result, String checkDetails, Integer checkedBy, LocalDateTime createTime, LocalDateTime updateTime) {
        this.checkId = checkId;
        this.productId = productId;
        this.checkDate = checkDate;
        this.result = result;
        this.checkDetails = checkDetails;
        this.checkedBy = checkedBy;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public Integer getCheckId() {
        return checkId;
    }

    public void setCheckId(Integer checkId) {
        this.checkId = checkId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public LocalDateTime getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(LocalDateTime checkDate) {
        this.checkDate = checkDate;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getCheckDetails() {
        return checkDetails;
    }

    public void setCheckDetails(String checkDetails) {
        this.checkDetails = checkDetails;
    }

    public Integer getCheckedBy() {
        return checkedBy;
    }

    public void setCheckedBy(Integer checkedBy) {
        this.checkedBy = checkedBy;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}
