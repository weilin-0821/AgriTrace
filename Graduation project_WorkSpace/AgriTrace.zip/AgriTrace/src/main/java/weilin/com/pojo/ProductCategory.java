package weilin.com.pojo;

import org.springframework.http.converter.json.GsonBuilderUtils;

import java.time.LocalDateTime;

public class ProductCategory {
    private Integer categoryId;    // 种类唯一ID
    private String categoryName;   // 种类名称
    private Boolean isProcessed;   // 是否经过深加工（0: 否, 1: 是）

    public ProductCategory(Integer categoryId, String categoryName, Boolean isProcessed) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.isProcessed = isProcessed;
    }

    public ProductCategory(String categoryName, Boolean isProcessed) {
        this.categoryName = categoryName;
        this.isProcessed = isProcessed;
    }

    public ProductCategory() {
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Boolean getIsProcessed() {
        return isProcessed;
    }

    public void setIsProcessed(Boolean processed) {
        isProcessed = processed;
    }

    @Override
    public String toString() {
        return "ProductCategory{" +
                "categoryId=" + categoryId +
                ", categoryName='" + categoryName + '\'' +
                ", isProcessed=" + isProcessed +
                '}';
    }
}
