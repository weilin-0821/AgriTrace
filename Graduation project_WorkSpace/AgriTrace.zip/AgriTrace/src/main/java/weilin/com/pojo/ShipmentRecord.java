package weilin.com.pojo;

import java.time.LocalDateTime;

public class ShipmentRecord {
    private Integer shipmentId;    // 运输记录唯一ID
    private Integer productId;     // 农产品ID（外键，关联Product表）
    private Integer originFarmId;  // 起始农场ID（外键，关联Farm表）
    private String destination;    // 目的地
    private LocalDateTime shipmentDate;     // 发货日期
    private Integer carrier;       // 承运商ID（外键，关联User表）
    private String trackingCode;   // 运输追踪码
    private LocalDateTime createTime;       // 创建时间
    private LocalDateTime updateTime;       // 修改时间

    public Integer getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(Integer shipmentId) {
        this.shipmentId = shipmentId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getOriginFarmId() {
        return originFarmId;
    }

    public void setOriginFarmId(Integer originFarmId) {
        this.originFarmId = originFarmId;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public LocalDateTime getShipmentDate() {
        return shipmentDate;
    }

    public void setShipmentDate(LocalDateTime shipmentDate) {
        this.shipmentDate = shipmentDate;
    }

    public Integer getCarrier() {
        return carrier;
    }

    public void setCarrier(Integer carrier) {
        this.carrier = carrier;
    }

    public String getTrackingCode() {
        return trackingCode;
    }

    public void setTrackingCode(String trackingCode) {
        this.trackingCode = trackingCode;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}
