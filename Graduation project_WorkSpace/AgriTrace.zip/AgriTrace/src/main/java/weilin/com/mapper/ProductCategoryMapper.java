package weilin.com.mapper;

import org.apache.ibatis.annotations.*;
import weilin.com.pojo.ProductCategory;

import java.util.List;

@Mapper
public interface ProductCategoryMapper {
    @Insert("insert into product_category(category_name, is_processed)" +
            " values (#{categoryName},#{isProcessed})")
    void addProductCategory(ProductCategory productCategory);

    @Select("select * from product_category")
    List<ProductCategory> getProductCategoryList();

    @Update("update product_category set category_name=#{categoryName},is_processed=#{isProcessed} where category_id=#{categoryId}")
    void updateProductCategory(ProductCategory productCategory);

    @Delete("delete from product_category where category_id=#{categoryId}")
    void deleteProductCategory(Integer categoryId);
}
