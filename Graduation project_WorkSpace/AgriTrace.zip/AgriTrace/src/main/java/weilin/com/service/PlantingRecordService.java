package weilin.com.service;

import org.springframework.stereotype.Service;
import weilin.com.pojo.PageBean;
import weilin.com.pojo.PlantingRecord;

import java.util.List;


public interface PlantingRecordService {

    public PageBean<PlantingRecord> list(Integer pageNum,
                                         Integer pageSize,
                                         Integer farmId,
                                         Integer productId);

    public void addPlantingRecord(PlantingRecord plantingRecord);
}
