package weilin.com.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import weilin.com.mapper.ProductMapper;
import weilin.com.pojo.PageBean;
import weilin.com.pojo.Product;
import weilin.com.service.ProductService;

import java.util.List;
@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductMapper productMapper;

    @Override
    public PageBean<Product> list(Integer pageNum, Integer pageSize, Integer categoryId, Integer farmId) {
        PageBean<Product> pageBean = new PageBean<>();
        PageHelper.startPage(pageNum, pageSize);
        List<Product> list = productMapper.list(categoryId, farmId);
        Page<Product> page =(Page<Product>) list;
        pageBean.setTotal(page.getTotal());
        pageBean.setItem(page.getResult());
        return pageBean;
    }

    @Override
    public void add(Product product) {
        productMapper.add(product);
    }

    @Override
    public void update(Product product) {
        productMapper.update(product);
    }

    @Override
    public void delete(Integer productId) {
        productMapper.delete(productId);
    }

    @Override
    public Product getProduct(Integer productId) {
        return productMapper.getProduct(productId);
    }

}
