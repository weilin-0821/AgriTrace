package weilin.com.service;

import weilin.com.pojo.ProductCategory;

import java.util.List;

public interface ProductCategoryService {
    //添加分类
    public void addProductCategory(ProductCategory productCategory);
    //获取所有分类
    public List<ProductCategory> getProductCategoryList();
    //更新分类
    public void updateProductCategory(ProductCategory productCategory);
    //删除分类
    public void deleteProductCategory(Integer productCategoryId);

}
