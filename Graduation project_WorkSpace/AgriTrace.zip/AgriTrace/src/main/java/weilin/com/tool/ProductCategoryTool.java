package weilin.com.tool;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import weilin.com.pojo.ProductCategory;
import weilin.com.service.ProductCategoryService;


import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

@Configuration
public class ProductCategoryTool {
    @Autowired
    private ProductCategoryService productCategoryService;

    @Bean
    @Description("删除产品分类,根据分类ID删除产品分类")
    public Function<ProductCategory,String> deleteProductionCategory(){
        return productCategory -> {
            productCategoryService.deleteProductCategory(productCategory.getCategoryId());
            return "删除成功";
        };
    }

    @Bean
    @Description("查询所有产品分类")
    public Function<Void,List<ProductCategory>> ProductCategoryList() {
        return  unused-> productCategoryService.getProductCategoryList();
    }

    @Bean
    @Description("添加商品分类,需要传入分类名称给categoryName，是否经过加工给isProcessed这两个参数是ProductCategory的属性")
    public Function<ProductCategory,String> addProductCategory() {
        return  productCategory -> {
            productCategoryService.addProductCategory(productCategory);
            return "添加成功";
        };
    }


}
