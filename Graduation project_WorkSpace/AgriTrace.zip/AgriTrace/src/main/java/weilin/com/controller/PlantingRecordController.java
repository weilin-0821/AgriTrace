package weilin.com.controller;

import io.lettuce.core.ScriptOutputType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import weilin.com.pojo.PageBean;
import weilin.com.pojo.PlantingRecord;
import weilin.com.pojo.Result;
import weilin.com.service.PlantingRecordService;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/record")
public class PlantingRecordController {

    @Autowired
    private PlantingRecordService plantingRecordService;

    @GetMapping("/list")
    public Result list(Integer pageNum,
                       Integer pageSize,
                       @RequestParam(required = false) Integer farmId,
                       @RequestParam(required = false) Integer productId){
        System.out.println("list:farmId:"+farmId+",productId:"+productId);
        PageBean<PlantingRecord> pageBean = plantingRecordService.list(pageNum, pageSize, farmId, productId);
        return Result.success(pageBean);
    }

    @PostMapping("/add")
    public Result add(@RequestBody PlantingRecord plantingRecord){
        System.out.println(plantingRecord);
        plantingRecordService.addPlantingRecord(plantingRecord);
        return Result.success();
    }

}
