package weilin.com.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import weilin.com.mapper.PlantingRecordMapper;
import weilin.com.pojo.PageBean;
import weilin.com.pojo.PlantingRecord;
import weilin.com.service.PlantingRecordService;

import java.util.List;

@Service
public class PlantingRecordServiceImpl implements PlantingRecordService {

    @Autowired
    private PlantingRecordMapper plantingRecordMapper;

    @Override
    public PageBean<PlantingRecord> list(Integer pageNum,
                                     Integer pageSize,
                                     Integer farmId,
                                     Integer productId) {

        PageBean<PlantingRecord> pageBean = new PageBean<>();
        PageHelper.startPage(pageNum, pageSize);
        List<PlantingRecord> list = plantingRecordMapper.list(farmId, productId);
        Page<PlantingRecord> page = (Page<PlantingRecord>) list;
        pageBean.setTotal(page.getTotal());
        pageBean.setItem(page.getResult());
        return pageBean;
    }

    @Override
    public void addPlantingRecord(PlantingRecord plantingRecord) {
        plantingRecordMapper.addRecord(plantingRecord);
    }
}
