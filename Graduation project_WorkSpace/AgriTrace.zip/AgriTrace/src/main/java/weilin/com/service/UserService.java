package weilin.com.service;

import weilin.com.pojo.User;

public interface UserService {
    //添加用户
    public void addUser(User user);
    //查找用户
    public User findUserByUsername(String username);

    public void updateUser(User user);
    public void updateAvatar(String avatar,Integer userId);
}
