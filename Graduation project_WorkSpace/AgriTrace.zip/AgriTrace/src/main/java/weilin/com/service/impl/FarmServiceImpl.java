package weilin.com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import weilin.com.mapper.FarmMapper;
import weilin.com.pojo.Farm;
import weilin.com.service.FarmService;
import weilin.com.utils.ThreadLocalUtil;

import java.util.List;

@Service
public class FarmServiceImpl implements FarmService {
    @Autowired
    private FarmMapper farmMapper;

    @Override
    public List<Farm> getAllFarmByUserId(Integer userId) {
        return farmMapper.selectAllByUserId(userId);
    }

    @Override
    public void addFarm(Farm farm) {
        farmMapper.addFarm(farm);
    }

    @Override
    public void updateFarm(Farm farm) {
        farmMapper.updateFarm(farm);
    }

    @Override
    public void deleteFarm(Integer farmId) {
        farmMapper.deleteFarm(farmId);
    }


}
