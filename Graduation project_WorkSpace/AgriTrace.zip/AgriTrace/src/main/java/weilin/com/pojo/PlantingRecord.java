package weilin.com.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;

public class PlantingRecord {
    private Integer recordId;      // 种植记录唯一ID
    private Integer productId;     // 农产品ID（外键，关联Product表）
    private Integer farmId;        // 农场ID（外键，关联Farm表）
    private LocalDateTime plantingDate;     // 种植日期
    private LocalDateTime harvestDate;      // 收获日期
    private String productName;
    private String farmName;
    private String plantingMethod; // 种植方法
    private String pesticideUsed;  // 使用的农药（如果有）
    private LocalDateTime createTime;       // 创建时间
    private LocalDateTime updateTime;       // 修改时间

    public PlantingRecord() {
    }

    public PlantingRecord(Integer recordId, Integer productId, Integer farmId, LocalDateTime plantingDate, LocalDateTime harvestDate, String productName, String farmName, String plantingMethod, String pesticideUsed, LocalDateTime createTime, LocalDateTime updateTime) {
        this.recordId = recordId;
        this.productId = productId;
        this.farmId = farmId;
        this.plantingDate = plantingDate;
        this.harvestDate = harvestDate;
        this.productName = productName;
        this.farmName = farmName;
        this.plantingMethod = plantingMethod;
        this.pesticideUsed = pesticideUsed;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public Integer getRecordId() {
        return recordId;
    }

    public void setRecordId(Integer recordId) {
        this.recordId = recordId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getFarmId() {
        return farmId;
    }

    public void setFarmId(Integer farmId) {
        this.farmId = farmId;
    }

    public LocalDateTime getPlantingDate() {
        return plantingDate;
    }

    public void setPlantingDate(LocalDateTime plantingDate) {
        this.plantingDate = plantingDate;
    }

    public LocalDateTime getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(LocalDateTime harvestDate) {
        this.harvestDate = harvestDate;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getFarmName() {
        return farmName;
    }

    public void setFarmName(String farmName) {
        this.farmName = farmName;
    }

    public String getPlantingMethod() {
        return plantingMethod;
    }

    public void setPlantingMethod(String plantingMethod) {
        this.plantingMethod = plantingMethod;
    }

    public String getPesticideUsed() {
        return pesticideUsed;
    }

    public void setPesticideUsed(String pesticideUsed) {
        this.pesticideUsed = pesticideUsed;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "PlantingRecord{" +
                "recordId=" + recordId +
                ", productId=" + productId +
                ", farmId=" + farmId +
                ", plantingDate=" + plantingDate +
                ", harvestDate=" + harvestDate +
                ", productName='" + productName + '\'' +
                ", farmName='" + farmName + '\'' +
                ", plantingMethod='" + plantingMethod + '\'' +
                ", pesticideUsed='" + pesticideUsed + '\'' +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                '}';
    }
}
