package weilin.com.pojo;

import java.time.LocalDateTime;

public class Farm {
    private Integer farmId;        // 农场唯一ID
    private String name;           // 农场名称
    private String location;       // 农场位置
    private String contactInfo;    // 联系信息
    private Integer userId;        // 用户ID（外键，关联User表）
    private LocalDateTime createTime;       // 创建时间
    private LocalDateTime updateTime;       // 修改时间

    public Farm() {
    }

    public Farm(Integer farmId, String name, String location, String contactInfo, Integer userId, LocalDateTime createTime, LocalDateTime updateTime) {
        this.farmId = farmId;
        this.name = name;
        this.location = location;
        this.contactInfo = contactInfo;
        this.userId = userId;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public Integer getFarmId() {
        return farmId;
    }

    public void setFarmId(Integer farmId) {
        this.farmId = farmId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}
