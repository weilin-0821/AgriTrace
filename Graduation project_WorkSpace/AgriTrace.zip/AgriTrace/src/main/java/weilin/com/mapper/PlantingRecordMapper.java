package weilin.com.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import weilin.com.pojo.PlantingRecord;

import java.util.List;

@Mapper
public interface PlantingRecordMapper {

    public List<PlantingRecord> list(Integer farmId,Integer productId);

    @Insert("insert into planting_record(product_id,farm_id,planting_date,harvest_date,pesticide_used,create_time,update_time) " +
            "values (#{productId},#{farmId},#{plantingDate},#{harvestDate},#{pesticideUsed},now(),now())")
    public void addRecord(PlantingRecord plantingRecord);
}
