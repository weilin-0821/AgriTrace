package weilin.com.mapper;

import org.apache.ibatis.annotations.*;
import weilin.com.pojo.Farm;

import java.util.List;

@Mapper
public interface FarmMapper {
    @Select("select * from farm where user_id=#{userId}")
    public List<Farm> selectAllByUserId(Integer userId);

    @Insert("insert into farm(name, location, contact_info, user_id, create_time, update_time) values " +
            "(#{name},#{location},#{contactInfo},#{userId},now(),now())")
    public void addFarm(Farm farm);

    @Update("update farm set name=#{name},location=#{location},contact_info=#{contactInfo}" +
            ",update_time=now() where farm_id=#{farmId} ")
    public void updateFarm(Farm farm);

    @Delete("delete from farm where farm_id=#{farmId}")
    public void deleteFarm(Integer farmId);
}
