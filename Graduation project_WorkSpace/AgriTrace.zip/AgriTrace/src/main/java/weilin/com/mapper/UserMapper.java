package weilin.com.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import weilin.com.pojo.User;

@Mapper
public interface UserMapper {
    //添加用户
    @Insert("insert into user(username, password, role, email, phone_number, avatar, create_time, update_time)" +
            " values (#{username},#{password},#{role},#{email},#{phoneNumber},#{avatar},now(),now())")
    void addUser(User user);

    //根据用户名查找用户
    @Select("select * from user where username=#{username}")
    User findUserByUsername(String username);

    @Update("update user set phone_number=#{phoneNumber},email=#{email},update_time=now() " +
            "where user_id=#{userId}")
    void updateUser(User user);

    @Update("update user set avatar=#{avatar} ,user.update_time=now() where user_id=#{userId}")
    void updateAvatar(String avatar,Integer userId);
}
