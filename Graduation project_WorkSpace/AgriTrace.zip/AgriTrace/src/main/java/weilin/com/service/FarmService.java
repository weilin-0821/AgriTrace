package weilin.com.service;

import weilin.com.pojo.Farm;

import java.util.List;

public interface FarmService {
    public List<Farm> getAllFarmByUserId(Integer userId);
    public void addFarm(Farm farm);
    public void updateFarm(Farm farm);
    public void deleteFarm(Integer farmId);
}
