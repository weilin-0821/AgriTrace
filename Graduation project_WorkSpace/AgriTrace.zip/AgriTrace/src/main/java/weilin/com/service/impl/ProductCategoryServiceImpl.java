package weilin.com.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import weilin.com.mapper.ProductCategoryMapper;
import weilin.com.pojo.ProductCategory;
import weilin.com.service.ProductCategoryService;

import java.util.List;

@Service
public class ProductCategoryServiceImpl implements ProductCategoryService {
    @Autowired
    private ProductCategoryMapper productCategoryMapper;
    //添加产品种类
    @Override
    public void addProductCategory(ProductCategory productCategory) {
        productCategoryMapper.addProductCategory(productCategory);
    }

    @Override
    public List<ProductCategory> getProductCategoryList() {
        return productCategoryMapper.getProductCategoryList();
    }

    @Override
    public void updateProductCategory(ProductCategory productCategory) {
        productCategoryMapper.updateProductCategory(productCategory);
    }

    @Override
    public void deleteProductCategory(Integer productCategoryId) {
        productCategoryMapper.deleteProductCategory(productCategoryId);
    }
}
