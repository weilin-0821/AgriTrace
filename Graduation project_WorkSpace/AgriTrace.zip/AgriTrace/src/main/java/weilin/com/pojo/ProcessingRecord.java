package weilin.com.pojo;

import java.time.LocalDateTime;

public class ProcessingRecord {

    private Integer processingId;  // 加工记录唯一ID
    private Integer productId;     // 农产品ID（外键，关联Product表）
    private LocalDateTime processingDate;   // 加工日期
    private Integer processedBy;   // 加工负责人ID（外键，关联User表）
    private String processingMethod; // 加工方法
    private String description;    // 加工说明
    private LocalDateTime createTime;       // 创建时间
    private LocalDateTime updateTime;       // 修改时间

    public ProcessingRecord() {
    }

    public Integer getProcessingId() {
        return processingId;
    }

    public void setProcessingId(Integer processingId) {
        this.processingId = processingId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public LocalDateTime getProcessingDate() {
        return processingDate;
    }

    public void setProcessingDate(LocalDateTime processingDate) {
        this.processingDate = processingDate;
    }

    public Integer getProcessedBy() {
        return processedBy;
    }

    public void setProcessedBy(Integer processedBy) {
        this.processedBy = processedBy;
    }

    public String getProcessingMethod() {
        return processingMethod;
    }

    public void setProcessingMethod(String processingMethod) {
        this.processingMethod = processingMethod;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public ProcessingRecord(Integer processingId, Integer productId, LocalDateTime processingDate, Integer processedBy, String processingMethod, String description, LocalDateTime createTime, LocalDateTime updateTime) {
        this.processingId = processingId;
        this.productId = productId;
        this.processingDate = processingDate;
        this.processedBy = processedBy;
        this.processingMethod = processingMethod;
        this.description = description;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }
}
