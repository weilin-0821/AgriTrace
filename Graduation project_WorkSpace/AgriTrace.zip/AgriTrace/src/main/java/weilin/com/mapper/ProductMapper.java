package weilin.com.mapper;

import org.apache.ibatis.annotations.*;
import weilin.com.pojo.Product;

import java.util.List;

@Mapper
public interface ProductMapper {


    @Insert("insert into product(name, description, farm_id, shelf_life, category_id, create_time, update_time) " +
            "values (#{name},#{description},#{farmId},#{shelfLife},#{categoryId},now(),now())")
    public void add(Product product);

    public List<Product> list(Integer categoryId, Integer farmId);

    @Update("update product set " +
            "name=#{name},description=#{description},farm_id=#{farmId},shelf_life=#{shelfLife},category_id=#{categoryId},update_time=now() " +
            "where product_id=#{productId}")
    public void update(Product product);

    @Delete("delete from product where product_id=#{productId}")
    public void delete(Integer productId);

    @Select("select * from product where product_id=#{productId}")
    public Product getProduct(Integer productId);
}
