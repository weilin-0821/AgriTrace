package weilin.com.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.web.bind.annotation.*;
import weilin.com.pojo.Result;
import weilin.com.pojo.User;
import weilin.com.service.UserService;
import weilin.com.utils.JwtUtil;
import weilin.com.utils.Md5Util;
import weilin.com.utils.ThreadLocalUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @PostMapping("/register")
    public Result register(@RequestParam String username, @RequestParam String password
    , @RequestParam String email, @RequestParam String phoneNumber, @RequestParam String role ) {
    User user=userService.findUserByUsername(username);
    if (user==null) {
        user=new User(username,new Md5Util().encode(password),role,email,phoneNumber);
        userService.addUser(user);
        return Result.success();
    }else{
        return Result.error("用户名已存在");
    }
    }

    @PostMapping("/login")
    public Result login(@RequestParam String username,@RequestParam String password) {
        System.out.println("login");
        User user=userService.findUserByUsername(username);
        if(user==null) {
            return Result.error("用户名错误");
        }else if(user.getPassword().equals(new Md5Util().encode(password))) {
            Map<String,Object> map=new HashMap<String,Object>();
            map.put("userId",user.getUserId());
            map.put("username",user.getUsername());
            String token= JwtUtil.genToken(map);
            ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
            ops.set(token,token,12, TimeUnit.HOURS);
            return Result.success(token);
        }else {
            return Result.error("密码错误");
        }
    }

    @GetMapping("/info")
    public Result info() {
        Map<String,Object> map= ThreadLocalUtil.get();
        return Result.success(userService.findUserByUsername((String) map.get("username")));
    }

    @PostMapping("/update")
    public Result updata(@RequestBody User user) {
        userService.updateUser(user);
        return Result.success();
    }

    @PostMapping("/updateAvatar")
    public Result updateAvatar(@RequestParam String avatar) {
        System.out.println("updateAvatar-----------------------------------------------------");
        Map<String,Object> map= ThreadLocalUtil.get();
        Integer userId=(Integer) map.get("userId");
        userService.updateAvatar(avatar,userId);
        return Result.success();
    }

}
