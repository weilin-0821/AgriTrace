package weilin.com.pojo;

import java.util.List;

public class PageBean<T>{
    private Long total;
    private List<T> item;

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public List<T> getItem() {
        return item;
    }

    public void setItem(List<T> item) {
        this.item = item;
    }
}
