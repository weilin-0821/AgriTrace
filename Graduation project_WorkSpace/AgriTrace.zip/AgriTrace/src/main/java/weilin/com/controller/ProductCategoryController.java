package weilin.com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.*;
import weilin.com.pojo.PageBean;
import weilin.com.pojo.ProductCategory;
import weilin.com.pojo.Result;
import weilin.com.service.ProductCategoryService;

import java.util.List;

@RestController
@RequestMapping("/category")
public class ProductCategoryController {
    @Autowired
    private ProductCategoryService productCategoryService;
    //添加分类
    @PostMapping("/add")
    public Result addProductCategory(@RequestParam String categoryName,@RequestParam Boolean isProcessed) {
        ProductCategory productCategory = new ProductCategory(categoryName,isProcessed);
        productCategoryService.addProductCategory(productCategory);
        return Result.success();
    }
    //分类列表
    @GetMapping("/list")
    public Result getProductCategoryList() {

        return Result.success(productCategoryService.getProductCategoryList());
    }

    @PostMapping("/update")
    public Result updateProductCategory(@RequestParam Integer categoryId, @RequestParam String categoryName,@RequestParam Boolean isProcessed) {
        ProductCategory productCategory = new ProductCategory(categoryId,categoryName,isProcessed);
        productCategoryService.updateProductCategory(productCategory);
        return Result.success("更新成功");
    }

    @DeleteMapping("/delete")
    public Result deleteProductCategory(Integer categoryId) {
        productCategoryService.deleteProductCategory(categoryId);
        return Result.success();
    }
}
