package weilin.com.pojo;

import java.time.LocalDateTime;

public class MarketSale {
    private Integer saleId;        // 销售记录唯一ID
    private Integer productId;     // 农产品ID（外键，关联Product表）
    private LocalDateTime saleDate;         // 销售日期
    private Integer userId;        // 销售负责人ID（外键，关联User表）
    private LocalDateTime createTime;       // 创建时间
    private LocalDateTime updateTime;       // 修改时间

    public MarketSale() {
    }

    public MarketSale(Integer saleId, Integer productId, LocalDateTime saleDate, Integer userId, LocalDateTime createTime, LocalDateTime updateTime) {
        this.saleId = saleId;
        this.productId = productId;
        this.saleDate = saleDate;
        this.userId = userId;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public Integer getSaleId() {
        return saleId;
    }

    public void setSaleId(Integer saleId) {
        this.saleId = saleId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public LocalDateTime getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(LocalDateTime saleDate) {
        this.saleDate = saleDate;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }
}
